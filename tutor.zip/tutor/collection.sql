-- phpMyAdmin SQL Dump
-- version 4.7.0
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1
-- Généré le :  mer. 01 avr. 2020 à 15:55
-- Version du serveur :  10.1.25-MariaDB
-- Version de PHP :  7.1.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données :  `collection`
--

-- --------------------------------------------------------

--
-- Structure de la table `booking`
--

CREATE TABLE `booking` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `class` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `booking`
--

INSERT INTO `booking` (`id`, `user_id`, `class`) VALUES
(1, 1, 'Primary 1'),
(2, 1, 'Primary 2'),
(3, 1, 'Nursery'),
(4, 1, 'Primary 6');

-- --------------------------------------------------------

--
-- Structure de la table `nursery`
--

CREATE TABLE `nursery` (
  `id` int(11) NOT NULL,
  `goal` varchar(255) NOT NULL,
  `subjects` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `nursery`
--

INSERT INTO `nursery` (`id`, `goal`, `subjects`) VALUES
(1, 'Improve phonics, reading and writing', 'Literacy'),
(2, 'Help with assignments and school wor', 'Numeracy'),
(3, 'Build foundation and confidence', 'Phonics'),
(4, 'Homeschooling', '');

-- --------------------------------------------------------

--
-- Structure de la table `primary`
--

CREATE TABLE `primary` (
  `int` int(11) NOT NULL,
  `goals` varchar(255) NOT NULL,
  `subject` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `primary`
--

INSERT INTO `primary` (`int`, `goals`, `subject`) VALUES
(1, 'Help with assignments and school work', 'Basic Mathematics'),
(2, 'Improve phonics, reading and writing', 'English Language'),
(3, '	\r\nEntrance exam preparation', 'Basic Sciences'),
(4, '	\r\nPrepare for school tests and exam', 'Verbal Reasoning');

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `booking`
--
ALTER TABLE `booking`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `nursery`
--
ALTER TABLE `nursery`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `primary`
--
ALTER TABLE `primary`
  ADD PRIMARY KEY (`int`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `booking`
--
ALTER TABLE `booking`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT pour la table `nursery`
--
ALTER TABLE `nursery`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT pour la table `primary`
--
ALTER TABLE `primary`
  MODIFY `int` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
